# CSS @counter-style Demo

Demo for the [@counter-style documentation](https://developer.mozilla.org/en-US/docs/Web/CSS/@counter-style) on Mozilla Developer Network.

See the live demo [here](https://mdn.github.io/css-examples/counter-style-demo/).
