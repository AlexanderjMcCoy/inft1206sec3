var cmInitContent = "transform: skew(30deg, 20deg);\n\n";
