var cmInitContent = "border-top-color: red;\n\n";
