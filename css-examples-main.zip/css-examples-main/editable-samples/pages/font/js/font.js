var cmInitContent = "font: italic 1.5em cursive;\n\n";
