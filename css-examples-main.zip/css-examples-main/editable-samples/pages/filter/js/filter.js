var cmInitContent = "filter: hue-rotate(180deg);\n\n";
